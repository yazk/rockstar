package guitar;
//import java.util.ArrayList;
//
//class Song
//{
//	// Create getters and setters rather than use public
//	private ArrayList<String> notes;
//	private ArrayList<Double> frequencies;
//	private ArrayList<Integer> guitarStrings;
//	private ArrayList<Integer> frets;
//	private ArrayList<Double> durations;
//
//	private int noteIndex;
//	private double bpm;
//	private String title;
//
//	public Song(String filename)
//	{
//		noteIndex = 0;
//
//		notes = new ArrayList<String>();
//		frequencies = new ArrayList<Double>();
//		guitarStrings = new ArrayList<Integer>();
//		frets = new ArrayList<Integer>();
//		durations = new ArrayList<Double>();
//
//		/*
//		 * Add(6, 5, 0.5); Add(5, 3, 0.5); Add(5, 5, 1);
//		 * 
//		 * Add(6, 5, 0.5); Add(5, 3, 0.5); Add(5, 6, 0.5); Add(5, 5, 1);
//		 * 
//		 * Add(6, 5, 0.5); Add(5, 3, 0.5); Add(5, 5, 0.5); Add(5, 3, 0.5);
//		 * Add(6, 5, 0.25); Add(6, 5, 0.5);
//		 */
//		// Smoke on the water fire in the sky
//		Add(6, 5, 0.5);
//
//		bpm = 60;
//
//		title = "Sample Song";
//	}
//
//	private void Add(String note, double frequency, int guitarString, int fret, double duration)
//	{
//		notes.add(note);
//		frequencies.add(frequency);
//		guitarStrings.add(guitarString);
//		frets.add(fret);
//		durations.add(duration);
//	}
//
//	private void Add(int guitarString, int fret, double duration)
//	{
//		FretData fd = SoundHelper.getFretData(guitarString, fret);
//
//		Add(fd.note, fd.frequency, guitarString, fret, duration);
//	}
//
//	public void IncreaseIndex()
//	{
//		noteIndex++;
//	}
//
//	public double getBPM()
//	{
//		return bpm;
//	}
//
//	public float getCompletion()
//	{
//		return (float) noteIndex / notes.size();
//	}
//
//	public String getTitle()
//	{
//		return title;
//	}
//
//	public String getNote()
//	{
//		return notes.get(noteIndex);
//	}
//
//	public int getGuitarString()
//	{
//		return guitarStrings.get(noteIndex);
//	}
//
//	public int getFret()
//	{
//		return frets.get(noteIndex);
//	}
//
//	public double getFrequency()
//	{
//		return frequencies.get(noteIndex);
//	}
//
//	public double getDuration()
//	{
//		return durations.get(noteIndex);
//	}
//
//	public boolean hasMore()
//	{
//		return noteIndex < notes.size() ? true : false;
//	}
//}