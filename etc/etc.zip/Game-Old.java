package game_a3d;

import com.ardor3d.bounding.BoundingBox;
import com.ardor3d.example.ExampleBase;
import com.ardor3d.extension.ui.UIButton;
import com.ardor3d.extension.ui.UICheckBox;
import com.ardor3d.extension.ui.UIFrame;
import com.ardor3d.extension.ui.UIHud;
import com.ardor3d.extension.ui.UILabel;
import com.ardor3d.extension.ui.UIPanel;
import com.ardor3d.extension.ui.UIProgressBar;
import com.ardor3d.extension.ui.UIRadioButton;
import com.ardor3d.extension.ui.layout.BorderLayout;
import com.ardor3d.extension.ui.layout.BorderLayoutData;
import com.ardor3d.extension.ui.layout.RowLayout;
import com.ardor3d.extension.ui.util.ButtonGroup;
import com.ardor3d.extension.ui.util.Dimension;
import com.ardor3d.extension.ui.util.SubTex;
import com.ardor3d.framework.Canvas;
import com.ardor3d.framework.FrameHandler;
import com.ardor3d.image.Texture;
import com.ardor3d.image.Image.Format;
import com.ardor3d.input.Key;
import com.ardor3d.input.logical.InputTrigger;
import com.ardor3d.input.logical.KeyPressedCondition;
import com.ardor3d.input.logical.LogicalLayer;
import com.ardor3d.input.logical.TriggerAction;
import com.ardor3d.input.logical.TwoInputStates;
import com.ardor3d.intersection.PickData;
import com.ardor3d.intersection.PickResults;
import com.ardor3d.intersection.PrimitivePickResults;
import com.ardor3d.light.PointLight;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.MathUtils;
import com.ardor3d.math.Matrix3;
import com.ardor3d.math.Ray3;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.queue.RenderBucketType;
import com.ardor3d.renderer.state.LightState;
import com.ardor3d.renderer.state.MaterialState;
import com.ardor3d.renderer.state.TextureState;
import com.ardor3d.renderer.state.MaterialState.ColorMaterial;
import com.ardor3d.scenegraph.Mesh;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.scenegraph.shape.Box;
import com.ardor3d.scenegraph.shape.Quad;
import com.ardor3d.ui.text.BasicText;
import com.ardor3d.util.ReadOnlyTimer;
import com.ardor3d.util.TextureManager;
import com.google.inject.Inject;
import com.sun.xml.internal.ws.api.message.Attachment;

/**
 * A simple example showing a textured and lit box spinning.
 */
public class Game extends ExampleBase
{
	private Mesh box; // Keep a reference to the box to be able to rotate it each frame.
	private final Matrix3 rotate = new Matrix3(); // Rotation matrix for the spinning box.
	private double angle = 0; // Angle of rotation for the box.
	private final Vector3 axis = new Vector3(1, 1, 0.5f).normalizeLocal(); // Axis to rotate the box around.

	private Quad title;
	private Quad fretBoard;

	private MaterialState materialState;

	private TextureState titleTextureState;
	private Texture titleTexture;

	private TextureState fretBoardTextureState;
	private Texture fretBoardTexture;

	private TextureState noteMarkerTextureState;
	private Texture noteMarkerTexture;

	private UIHud hud;
	private UILabel fpslabel;
	private UIProgressBar bar;

	private double counter = 0;
	private int frames = 0;

	private final int WIDTH = 720;
	private final int HEIGHT = (int) (WIDTH * 1.6);

	private Node titleNode;
	private Node gameNode;
	private Node optionsNode;
	private TitleScene titleScene;
	
	private BasicText text;

	public static void main(final String[] args)
	{
		start(Game.class);
	}

	@Inject
	public Game(final LogicalLayer logicalLayer, final FrameHandler frameWork)
	{
		super(logicalLayer, frameWork);
	}

	protected void updateExample(final ReadOnlyTimer timer)
	{
		// Update the angle using the current tpf to rotate at a constant speed.
		angle += timer.getTimePerFrame() * 50;
		// Wrap the angle to keep it inside 0-360 range
		angle %= 360;

		// Update the rotation matrix using the angle and rotation axis.
		rotate.fromAngleNormalAxis(angle * MathUtils.DEG_TO_RAD, axis);
		// Update the box rotation using the rotation matrix.
		box.setRotation(rotate);

		// /////////////////////////////////////////////////////////////////////////////

		counter += timer.getTimePerFrame();
		frames++;
		if (counter > 1)
		{
			final double fps = (frames / counter);
			counter = 0;
			frames = 0;
			System.out.printf("%7.1f FPS\n", fps);
			fpslabel.setText(fps + " FPS");
			bar.setPercentFilled(timer.getTimeInSeconds() / 15);
			bar.updateMinimumSizeFromContents();
			
			text.setText(Float.toString((float)fps));
		}

		hud.updateGeometricState(timer.getTimePerFrame());
		
		
		
		//titleScene.update(timer);
	}

	protected void initExample()
	{
		_canvas.setTitle("PRS");
		_canvas.setVSyncEnabled(true);

		// Texture setup
		titleTexture = TextureManager.load("img/title.png", Texture.MinificationFilter.Trilinear, Format.GuessNoCompression, true);
		fretBoardTexture = TextureManager.load("img/fretBoard.png", Texture.MinificationFilter.Trilinear, Format.GuessNoCompression, true);
		noteMarkerTexture = TextureManager.load("img/noteMarker.png", Texture.MinificationFilter.Trilinear, Format.GuessNoCompression, true);

		// State setup
		titleTextureState = new TextureState();
		fretBoardTextureState = new TextureState();
		noteMarkerTextureState = new TextureState();
		materialState = new MaterialState();

		// Texture state setup
		titleTextureState.setTexture(titleTexture);
		fretBoardTextureState.setTexture(fretBoardTexture);
		noteMarkerTextureState.setTexture(noteMarkerTexture);

		// Material state setup
		materialState.setColorMaterial(ColorMaterial.Diffuse);

		// Box setup
		box = new Box("Box", new Vector3(0, 0, 0), 5, 5, 5); // Create a new box centered at (0,0,0) with width/height/depth of size 10.
		box.setModelBound(new BoundingBox()); // Set a bounding box for frustum culling.
		box.setTranslation(new Vector3(0, 0, -15)); // Move the box out from the camera 15 units.
		box.setRenderState(fretBoardTextureState);
		box.setRenderState(materialState); // Add a material to the box, to show both vertex color and lighting/shading.

		// Title
		title = new Quad("title", 7, 2);
		title.setModelBound(new BoundingBox());
		title.setRenderState(titleTextureState);
		title.setRenderState(materialState);

		// Fret Board
		fretBoard = new Quad("fretBoard", 2, 2);
		fretBoard.setModelBound(new BoundingBox());
		fretBoard.setTranslation(new Vector3(-2, -2, 0));
		fretBoard.setRenderState(fretBoardTextureState);
		fretBoard.setRenderState(materialState);

		//
		text = BasicText.createDefaultTextLabel("text", "Hello world");
		text.setTranslation(10, 10, 0);
		text.setRandomColors();

		// Attach shapes

		titleNode = new Node("title");

		titleNode.attachChild(box);
		titleNode.attachChild(title);
		titleNode.attachChild(text);


		gameNode = new Node("game");

		gameNode.attachChild(box);
		gameNode.attachChild(fretBoard);

		_root.attachChild(titleNode);

		makeUI();


		_logicalLayer.registerTrigger(new InputTrigger(new KeyPressedCondition(Key.SPACE), new TriggerAction()
		{
			public void perform(final Canvas source, final TwoInputStates inputStates, final double tpf)
			{
				System.out.println("Space was pressesd");
			}
		}));
		
		
		titleScene = new TitleScene();
		
		LightState lightState = new LightState();
		lightState.setEnabled(true);
		lightState.attach(TitleScene.makeLight());
		_root.setRenderState(lightState);
		
		
		_root.attachChild(titleScene.getRoot());
	}

	private void makeUI()
	{
		final UIPanel panel = new UIPanel();
		panel.setForegroundColor(ColorRGBA.DARK_GRAY);
		panel.setLayout(new BorderLayout());

		final UIButton button = new UIButton("Button A");
		button.setIcon(new SubTex(titleTexture));
		button.setIconDimensions(new Dimension(26, 26));
		button.setGap(10);
		button.setLayoutData(BorderLayoutData.NORTH);
		button.setTooltipText("This is a tooltip!");
		panel.add(button);

		final RowLayout rowLay = new RowLayout(false);
		rowLay.setExpands(false);
		final UIPanel centerPanel = new UIPanel(rowLay);
		centerPanel.setLayoutData(BorderLayoutData.CENTER);
		panel.add(centerPanel);

		final UICheckBox check1 = new UICheckBox("Hello");
		check1.setSelected(true);
		check1.setEnabled(false);
		centerPanel.add(check1);
		final UICheckBox check2 = new UICheckBox("World");
		centerPanel.add(check2);

		final ButtonGroup group = new ButtonGroup();
		final UIRadioButton radio1 = new UIRadioButton("option A");
		radio1.setGroup(group);
		centerPanel.add(radio1);
		final UIRadioButton radio2 = new UIRadioButton("option B");
		radio2.setGroup(group);
		centerPanel.add(radio2);

		bar = new UIProgressBar("Loading: ", true);
		bar.setPercentFilled(0);
		bar.setComponentWidth(250);
		bar.setLayoutResizeableX(false);
		centerPanel.add(bar);

		fpslabel = new UILabel("FPS");
		fpslabel.setLayoutData(BorderLayoutData.SOUTH);
		panel.add(fpslabel);

		final UIFrame frame = new UIFrame("Sample");
		frame.setContentPanel(panel);
		frame.updateMinimumSizeFromContents();
		frame.layout();
		frame.pack();

		frame.setUseStandin(true);
		UIFrame.setUseTransparency(false);
		frame.setLocationRelativeTo(_canvas.getCanvasRenderer().getCamera());
		frame.setName("sample");

		hud = new UIHud();
		//hud.add(frame);
		hud.setupInput(_canvas, _physicalLayer, _logicalLayer);

	}

	@Override
	protected void updateLogicalLayer(final ReadOnlyTimer timer)
	{
		hud.getLogicalLayer().checkTriggers(timer.getTimePerFrame());
	}

	@Override
	protected void renderExample(final Renderer renderer)
	{
		
		super.renderExample(renderer);
		renderer.renderBuckets();
		renderer.draw(hud);
		
		titleScene.renderUnto(renderer);
	}

	@Override
	public PickResults doPick(final Ray3 pickRay)
	{
		PickResults pickResults = super.doPick(pickRay);

		System.out.println("Pick");
		
		for (int i = 0; i < pickResults.getNumber(); i++)
		{
			PickData pickData = pickResults.getPickData(i);

			System.out.println(i + ") " + pickData.getTargetMesh().toString());
		}

		return pickResults;
	}
	
    protected void processPicks(final PrimitivePickResults pickResults) {
        int i = 0;
        while (pickResults.getNumber() > 0
                && pickResults.getPickData(i).getIntersectionRecord().getNumberOfIntersection() == 0
                && ++i < pickResults.getNumber()) {
        }
        if (pickResults.getNumber() > i) {
            final PickData pick = pickResults.getPickData(i);
            System.err.println("picked: " + pick.getTargetMesh() + " at: "
                    + pick.getIntersectionRecord().getIntersectionPoint(0));
        } else {
            System.err.println("picked: nothing");
        }
    }
}
