package game_a3d;

import java.net.URISyntaxException;

import com.ardor3d.bounding.BoundingBox;
import com.ardor3d.framework.Scene;
import com.ardor3d.image.Texture;
import com.ardor3d.image.Image.Format;
import com.ardor3d.image.util.AWTImageLoader;
import com.ardor3d.intersection.PickResults;
import com.ardor3d.light.Light;
import com.ardor3d.light.PointLight;
import com.ardor3d.math.ColorRGBA;
import com.ardor3d.math.Ray3;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.queue.RenderBucketType;
import com.ardor3d.renderer.state.LightState;
import com.ardor3d.renderer.state.MaterialState;
import com.ardor3d.renderer.state.TextureState;
import com.ardor3d.renderer.state.ZBufferState;
import com.ardor3d.renderer.state.MaterialState.ColorMaterial;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.scenegraph.shape.Box;
import com.ardor3d.util.TextureManager;
import com.ardor3d.util.resource.ResourceLocatorTool;
import com.ardor3d.util.resource.SimpleResourceLocator;

public class TitleScene implements Scene
{

	private final Node root = new Node();

	private Box box;

	private Texture testTexture;
	private LightState lightState;

	private TextureState testTextureState;
	private MaterialState materialState;

	public TitleScene()
	{
		init();
	}

	public static Light makeLight()
	{
		final PointLight light = new PointLight();
		light.setDiffuse(new ColorRGBA(0.0f, 1f, 0.0f, 1f));
		light.setAmbient(new ColorRGBA(0.8f, 1f, 0.8f, 1f));
		light.setLocation(new Vector3(0, 0, 5));
		light.setEnabled(true);

		return light;
	}

	@Override
	public PickResults doPick(final Ray3 pickRay)
	{
		// Ignore
		return null;
	}

	@Override
	public boolean renderUnto(final Renderer renderer)
	{
		renderer.draw(root);
		return true;
	}

	// @Override
	public void init()
	{

		AWTImageLoader.registerLoader();

		try
		{
			final SimpleResourceLocator srl = new SimpleResourceLocator(TitleScene.class.getClassLoader().getResource("com/ardor3d/example/media/"));
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_TEXTURE, srl);
		}
		catch (final URISyntaxException ex)
		{
			ex.printStackTrace();
		}

		// State setup
		testTextureState = new TextureState();
		testTextureState.setTexture(TextureManager.load("img/test.png", Texture.MinificationFilter.Trilinear, Format.GuessNoCompression, true));

		materialState = new MaterialState();
		materialState.setColorMaterial(ColorMaterial.Diffuse);
		lightState = new LightState();
		lightState.attach(makeLight());
		lightState.setNeedsRefresh(true);
		lightState.setEnabled(true);

		// Box setup
		box = new Box("myBox", new Vector3(0, 0, 0), 4, 2, 1);
		box.setModelBound(new BoundingBox());
		box.setRenderState(materialState);
		box.setSolidColor(ColorRGBA.WHITE);
		//box.setLightState(lightState);
		box.setRenderState(testTextureState);
		//box.setRandomColors();

		root.attachChild(box);

		root.setRenderState(lightState);

        final ZBufferState zBufferState = new ZBufferState();
        zBufferState.setEnabled(true);
        zBufferState.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
        root.setRenderState(zBufferState);
	}

	public Node getRoot()
	{
		return root;
	}
}
