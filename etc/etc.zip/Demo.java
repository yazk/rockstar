package game_a3d;

import com.ardor3d.framework.DisplaySettings;
import com.ardor3d.framework.Updater;
import com.ardor3d.framework.lwjgl.LwjglCanvas;
import com.ardor3d.framework.lwjgl.LwjglCanvasRenderer;
import com.ardor3d.math.MathUtils;
import com.ardor3d.math.Matrix3;
import com.ardor3d.math.Vector3;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.scenegraph.shape.Box;

import com.ardor3d.util.ReadOnlyTimer;
import com.ardor3d.util.Timer;

public class Demo implements Updater
{
	private TitleScene titleScene;
	private Node root;
	private LwjglCanvas canvas;
	private boolean exit = false;
	private Timer timer = new Timer();

	public static void main(String[] args)
	{
		new Demo();
	}

	public Demo()
	{
		init();

		// Run in this same thread.
		while (!exit)
		{
			if (canvas.isClosing())
			{
				exit = true;
				return;
			}

			update(timer);

			Thread.yield();
		}

		canvas.close();
	}

	@Override
	public void init()
	{
		titleScene = new TitleScene();
		root = titleScene.getRoot();

		LwjglCanvasRenderer canvasRenderer = new LwjglCanvasRenderer(titleScene);
		DisplaySettings settings = new DisplaySettings((int) (480 * 1.6), 480, 24, 0, 0, 8, 0, 0, false, false);
		canvas = new LwjglCanvas(canvasRenderer, settings);
		canvas.setTitle("Demo");
		canvas.init();
	}

	private final Vector3 axis = new Vector3(0, 1, 0f).normalizeLocal();
	private final Matrix3 rotate = new Matrix3();
	private double angle = 0;

	@Override
	public void update(ReadOnlyTimer timer)
	{
		this.timer.update();

		Box box = (Box) root.getChild("myBox");
		// root.updateGeometricState(timer.getTimePerFrame(), true);

		// update our rotation
		angle = angle + (timer.getTimePerFrame() * 25);
		if (angle > 180)
		{
			angle = -180;
		}

		rotate.fromAngleNormalAxis(angle * MathUtils.DEG_TO_RAD, axis);
		box.setRotation(rotate);

		canvas.draw(null);

		// Update controllers/render states/transforms/bounds for rootNode.
		root.updateGeometricState(timer.getTimePerFrame(), true);
	}

}
