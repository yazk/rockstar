package game_a3d;

import java.net.URISyntaxException;

import com.ardor3d.bounding.BoundingBox;
import com.ardor3d.example.ExampleBase;
import com.ardor3d.framework.DisplaySettings;
import com.ardor3d.framework.Scene;
import com.ardor3d.framework.Updater;
import com.ardor3d.framework.lwjgl.LwjglCanvas;
import com.ardor3d.framework.lwjgl.LwjglCanvasRenderer;
import com.ardor3d.image.Texture;
import com.ardor3d.image.Image.Format;
import com.ardor3d.image.util.AWTImageLoader;
import com.ardor3d.intersection.PickResults;
import com.ardor3d.light.PointLight;
import com.ardor3d.math.MathUtils;
import com.ardor3d.math.Matrix3;
import com.ardor3d.math.Ray3;
import com.ardor3d.math.Vector3;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.state.LightState;
import com.ardor3d.renderer.state.MaterialState;
import com.ardor3d.renderer.state.TextureState;
import com.ardor3d.renderer.state.ZBufferState;
import com.ardor3d.renderer.state.MaterialState.ColorMaterial;
import com.ardor3d.scenegraph.Node;
import com.ardor3d.scenegraph.Spatial;
import com.ardor3d.scenegraph.controller.SpatialController;
import com.ardor3d.scenegraph.shape.Box;
import com.ardor3d.util.ContextGarbageCollector;
import com.ardor3d.util.ReadOnlyTimer;
import com.ardor3d.util.TextureManager;
import com.ardor3d.util.Timer;
import com.ardor3d.util.resource.ResourceLocatorTool;
import com.ardor3d.util.resource.SimpleResourceLocator;

public class SimpleDemo implements Scene, Updater
{
	private final LwjglCanvas canvas;

	private final Timer timer = new Timer();

	private boolean exit = false;

	private final Node root = new Node();

	private Box box;

	public static void main(final String[] args)
	{
		final SimpleDemo example = new SimpleDemo();
		example.start();
	}

	// Constructs the example class, also creating the native window and GL surface.
	public SimpleDemo()
	{
		final LwjglCanvasRenderer canvasRenderer = new LwjglCanvasRenderer(this);
		final DisplaySettings settings = new DisplaySettings((int) (480 * 1.6), 480, 24, 0, 0, 8, 0, 0, false, false);
		canvas = new LwjglCanvas(canvasRenderer, settings);
		canvas.init();
	}

	// Kicks off the example logic, first setting up the scene, then continuously updating and rendering it until exit is flagged.
	// Afterwards, the scene and gl surface are cleaned up.
	private void start()
	{
		initExample();

		// Run in this same thread.
		while (!exit)
		{

			// Update our scene... Check if the window is closing.
			// Then update our timer and finally update the geometric state of the root and its children.
			if (canvas.isClosing())
			{
				exit = true;
				return;
			}

			timer.update();

			// Update controllers/render states/transforms/bounds for rootNode.
			root.updateGeometricState(timer.getTimePerFrame(), true);

			update(timer);
			canvas.draw(null);
			Thread.yield();
		}

		// Done, do cleanup
		ContextGarbageCollector.doFinalCleanup(canvas.getCanvasRenderer().getRenderer());
		canvas.close();
	}

	// Initialize our scene.
	private void initExample()
	{
		canvas.setTitle("SimpleDemo - close window to exit");

		MaterialState materialState = new MaterialState();
		materialState.setColorMaterial(ColorMaterial.Diffuse);

		PointLight light = (PointLight) TitleScene.makeLight();
		LightState lightState = new LightState();
		lightState.attach(light);
		lightState.setEnabled(true);

		// box.setRandomColors();
		box = new Box("Box", Vector3.ZERO, 2,2,2);
		box.setModelBound(new BoundingBox());
		box.setRenderState(materialState);
		//box.setLightState(lightState); // apparently this was foobaring it

		root.setRenderState(lightState);
		root.attachChild(box);
		
		
		// Add our awt based image loader.
		AWTImageLoader.registerLoader();

		// Set the location of our example resources.
		try
		{
			final SimpleResourceLocator srl = new SimpleResourceLocator(ExampleBase.class.getClassLoader().getResource("com/ardor3d/example/media/"));
			ResourceLocatorTool.addResourceLocator(ResourceLocatorTool.TYPE_TEXTURE, srl);
		}
		catch (final URISyntaxException ex)
		{
			ex.printStackTrace();
		}

		// Create a ZBuffer to display pixels closest to the camera above farther ones.
		final ZBufferState buf = new ZBufferState();
		buf.setEnabled(true);
		buf.setFunction(ZBufferState.TestFunction.LessThanOrEqualTo);
		root.setRenderState(buf);

		// Create a texture from the Ardor3D logo.
		final TextureState ts = new TextureState();
		ts.setEnabled(true);
		ts.setTexture(TextureManager.load("images/ardor3d_white_256.jpg", Texture.MinificationFilter.Trilinear, Format.GuessNoCompression, true));
		root.setRenderState(ts);
	}

	// ------ Scene methods ------

	public boolean renderUnto(final Renderer renderer)
	{
		if (!canvas.isClosing())
		{

			// Draw the root and all its children.
			renderer.draw(root);

			return true;
		}
		return false;
	}

	public PickResults doPick(final Ray3 pickRay)
	{
		return null;
	}

	@Override
	public void init()
	{
		// TODO Auto-generated method stub

	}

	private final Vector3 axis = new Vector3(1, 1, 0.5f).normalizeLocal();
	private final Matrix3 rotate = new Matrix3();
	private double angle = 0;

	@Override
	public void update(ReadOnlyTimer timer)
	{
		// update our rotation
		angle = angle + (timer.getTimePerFrame() * 25);
		if (angle > 180)
		{
			angle = -180;
		}

		rotate.fromAngleNormalAxis(angle * MathUtils.DEG_TO_RAD, axis);
		box.setRotation(rotate);
	}
}
