package com.worldwizards.darkmmo.client;

import java.util.ArrayList;
import java.util.List;

import com.ardor3d.framework.Canvas;
import com.ardor3d.framework.DisplaySettings;
import com.ardor3d.framework.NativeCanvas;
import com.ardor3d.framework.Scene;
import com.ardor3d.framework.lwjgl.LwjglCanvas;
import com.ardor3d.framework.lwjgl.LwjglCanvasRenderer;
import com.ardor3d.input.MouseManager;
import com.ardor3d.input.PhysicalLayer;
import com.ardor3d.input.logical.LogicalLayer;
import com.ardor3d.input.lwjgl.LwjglKeyboardWrapper;
import com.ardor3d.input.lwjgl.LwjglMouseManager;
import com.ardor3d.input.lwjgl.LwjglMouseWrapper;
import com.ardor3d.intersection.PickResults;
import com.ardor3d.math.Ray3;
import com.ardor3d.renderer.Renderer;
import com.ardor3d.renderer.TextureRendererFactory;
import com.ardor3d.renderer.lwjgl.LwjglTextureRendererProvider;
import com.ardor3d.util.TextureManager;
import com.ardor3d.util.Timer;


public abstract class AbstractClient implements Scene {
	private List<RenderPass> _passes = new ArrayList<RenderPass>();
	protected Canvas _canvas;
    protected LogicalLayer _logicalLayer;
    protected final MouseManager _mouseManager;
    protected final Timer _timer = new Timer();
    protected boolean _exit=false;
	
	public AbstractClient(){
		super();
		_mouseManager= new LwjglMouseManager();
		
		
	}
	
	public void addRenderPass(RenderPass pass){
		_passes.add(pass);
	}
	
	public void removeRenderPass(RenderPass pass){
		_passes.remove(pass);
	}
	
	public Canvas getCanvas(){
		return _canvas;
	}
	
	public LogicalLayer getLogicalLayer(){
		return _logicalLayer;
	}
	
	
	/**
     * Setup an lwjgl canvas and canvas renderer.
     * 
     * @return the canvas.
     */
    private LwjglCanvas initLwjgl() {
        final LwjglCanvasRenderer canvasRenderer = new LwjglCanvasRenderer(this);
        final DisplaySettings settings = new DisplaySettings(800, 600, 24, 0, 0, 8, 0, 0, false, false);
        TextureRendererFactory.INSTANCE.setProvider(new LwjglTextureRendererProvider());
        return new LwjglCanvas(canvasRenderer, settings);
    }
    
    private void cleanupLwjglCanvas(LwjglCanvas lwjglCanvas){
    
        lwjglCanvas.close();
    }
    
    protected void start() {
    	initAbstractClient();
    	initClient();
		initPasses();
		
        // Run in this same thread.
        while (!_exit) {
            update();
            _canvas.draw(null);
            Thread.yield();
        }

        // Done, do cleanup
       
        if (_canvas instanceof LwjglCanvas){
        	cleanupLwjglCanvas((LwjglCanvas)_canvas);
        }
       
		
	}
	
	private void initAbstractClient() {
		 _canvas = initLwjgl();
	     _canvas.init();
	     PhysicalLayer physicalLayer = new PhysicalLayer(new LwjglKeyboardWrapper(),
	        		new LwjglMouseWrapper(), (LwjglCanvas)_canvas);
	     _logicalLayer = new LogicalLayer();
	 	 _logicalLayer.registerInput(_canvas, physicalLayer);
	}

	protected abstract void initClient();

	public PickResults doPick(Ray3 pickRay) {
		// TODO Auto-generated method stub
		return null;
	}
	
	protected void initPasses(){
		for(RenderPass pass : _passes){
	    	 pass.init(this);
	     }
	}
	
	protected void update(){
		if ((_canvas instanceof NativeCanvas)&&((NativeCanvas)_canvas).isClosing()) {
         //if (((LwjglCanvas)_canvas).isClosing() ){
			_exit = true;
            return;
        }

        _timer.update();
        double time =_timer.getTimePerFrame();
        _logicalLayer.checkTriggers(time);
        for(RenderPass pass : _passes){
	    	 pass.update(time);
	     }
         
	}

	public boolean renderUnto(Renderer renderer) {
		 if ((_canvas instanceof NativeCanvas)&&((NativeCanvas)_canvas).isClosing()) {
			 return false;
		 }
		
	     for(RenderPass pass : _passes){
	    	 pass.render(renderer);
	     }
	     return true;
	}


}